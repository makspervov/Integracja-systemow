<?php

class Cities{

    private $citiesTable = "city";
    public $ID;
    public $Name;
    public $CountryCode;
    public $District;
    public $Population;
    
    public function __construct($db){
        $this->conn = $db;
    }

    function read(){
        if($this->ID) {
            $stmt = $this->conn->prepare("SELECT * FROM ".$this->citiesTable." WHERE ID = ?");
            $stmt->bind_param("i", $this->ID);
        } else {
            $stmt = $this->conn->prepare("SELECT * FROM " . $this->citiesTable);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        return $result;
    }
    
    function write(){
        if($this->ID) {
            $stmt2 = $this->conn->prepare("INSERT INTO ".$this->citiesTable." (`ID`, `Name`, `CountryCode`, `District`, `Population`) VALUES(?, ?, ?, ?, ?)");
            $stmt2->bind_param("issss", $this->ID, $this->Name, $this->CountryCode, $this->District, $this->Population);
        }
        $stmt2->execute();
        $affected_rows = $stmt2->affected_rows;
        if ($affected_rows > 0) {
            return 0;
        } else {
            return 1;
        }
    }
    
    function update(){
        if($this->ID && $this->Name && $this->CountryCode && $this->District && $this->Population) {
            $stmt3 = $this->conn->prepare("UPDATE ".$this->citiesTable." SET `Name`=?,`CountryCode`=?,`District`=?,`Population`=? WHERE ID=?");
            $stmt3->bind_param("sssii",$this->Name, $this->CountryCode, $this->District, $this->Population, $this->ID);
        }
        $stmt3->execute();
        $affected_rows = $stmt3->affected_rows;
        if ($affected_rows > 0) {
            return 0;
        } else {
            return 1;
        }
    }
    
    function delete(){
        if($this->ID) {
            $stmt4 = $this->conn->prepare("DELETE FROM ".$this->citiesTable." WHERE `ID`= ?");
            $stmt4->bind_param("i", $this->ID);
        }
        $stmt4->execute();
        $affected_rows = $stmt4->affected_rows;
        if ($affected_rows > 0) {
            return 0;
        } else {
            return 1;
        }
    }
}

