<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/Database.php';
include_once '../class/Cities.php';

$database = new Database();
$db = $database->getConnection();

$cities = new Cities($db);

$cities->ID = (isset($_GET['ID']) && $_GET['ID']) ? $_GET['ID'] : '0';
$cities->Name = (isset($_GET['Name']) && $_GET['Name']) ? $_GET['Name'] : '0';
$cities->CountryCode = (isset($_GET['CountryCode']) && $_GET['CountryCode']) ? $_GET['CountryCode'] : '0';
$cities->District = (isset($_GET['District']) && $_GET['District']) ? $_GET['District'] : '0';
$cities->Population = (isset($_GET['Population']) && $_GET['Population']) ? $_GET['Population'] : '0';

$result = $cities->update();
if($result == 0){
    http_response_code(200);
    echo json_encode(array("message" => "City updated succesfully."));
}
else {
    http_response_code(404);
    echo json_encode(array("message" => "Failed to update city."));
}