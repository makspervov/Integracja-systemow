﻿namespace IS_LAB8_JWT.Entities
{
    public class Role
    {
        public string Role_ { get; set; }
    }
}
